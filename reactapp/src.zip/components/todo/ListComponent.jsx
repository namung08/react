import React, {useEffect, useState} from 'react';
import UseCustomMove from "../../hooks/useCustomMove.jsx";
import {getList} from "../../api/todoApi.jsx";

const initState = {
    dtoList: [],
    pageNumList: [],
    pageRequestDTO: null,
    prev: false,
    next: false,
    totalCount: 0,
    prevPage: 0,
    nextPage: 0,
    totalPage: 0,
    current: 0
}

const ListComponent = () => {
    const [serverData, setServerData] = useState(initState)
    const {page, size} = UseCustomMove()

    useEffect(() => {
        getList({page, size})
            .then(data => {
                setServerData(data)
            })
    }, [page, size]);
    console.log(serverData)


    return (
        <div className="border-2 border-blue-100 mt-10 mr-2 ml-2">
            <div className="flex flex-wrap mx-auto justify-center p-6">
                <div className="w-full min-w-[400px] p-2 m-2 rounded shadow-md  bg-white">
                    {serverData.dtoList.map((dtoList,i) => {
                        return (
                            <div className="flex ">
                                <div className="font-extrabold text-2xl p-2 w-1/12">{dtoList.tno}</div>
                                <div className="text-1xl m-1 p-2 w-8/12 font-extrabold">{dtoList.title}</div>
                                <div className="text-1xl m-1 p-2 w-2/10 font-medium">{dtoList.writer}</div>
                            </div>
                        )
                    })}
                </div>
            </div>
        </div>
    );
};

export default ListComponent;
