import React from 'react';
import { createSearchParams, useNavigate, useSearchParams } from "react-router-dom";

const getNum = (param, defaultValue) => {
    if (!param) {
        return defaultValue;
    }
    return parseInt(param, 10);  // 안전한 변환을 위해 기수(radix)를 명시적으로 지정
}

const useCustomMove = () => {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();  // 수정된 부분: searchParams 사용

    const page = getNum(searchParams.get('page'), 1);
    const size = getNum(searchParams.get('size'), 10);
    const queryDefault = createSearchParams({ page, size }).toString();

    const moveToList = (pageParam = page) => {  // pageParam 사용, 기본값을 현재 페이지로 설정
        let queryStr = "";
        if(pageParam) {
            const pageNum = getNum(pageParam.page,1)
            const sizeNum = getNum(pageParam.size,10)
            queryStr = createSearchParams({page:pageNum,size:sizeNum}).toString()
        } else {
            queryStr = queryDefault
        }
        navigate({pathname:`../list`,search:queryStr});
    }

    // 수정 페이지 이동
    const moveToModify = (num) => {
        navigate({
            pathname : `../modify/${num}`,
            search : queryDefault
        })
    }

    return { moveToList, moveToModify,page,size };
};

export default useCustomMove;
