import BasicLayout from "../layouts/BasicLayout.jsx";

function About() {
    return(
        <BasicLayout>
            <div className={'text-3xl'}>
                <div>AboutPage</div>
            </div>
        </BasicLayout>
    )
}

export default About;