import React from 'react';

const AddPage = () => {
    return (
        <div className="p-4 w-full bg-orange-200 ">
            <div className="text-3xl font-extrabold">
                Todo Add Page Component
            </div>
        </div>
    );
};

export default AddPage;