import React from 'react';

const ModifyPage = () => {
    return (
        <div className="p-4 w-full bg-orange-200 ">
            <div className="text-3xl font-extrabold">
                Todo Modify Page
            </div>
        </div>
    );
};

export default ModifyPage;